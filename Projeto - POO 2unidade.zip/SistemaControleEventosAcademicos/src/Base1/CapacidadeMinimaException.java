package Base1;

@SuppressWarnings("serial")
public class CapacidadeMinimaException extends Exception{
	
	public CapacidadeMinimaException() {
		super("Quantidade minima exigida foi atingida!");
	}

	public CapacidadeMinimaException(String message) {
        super(message);
    }
}
