package Base1;

public enum TipoEvento {
	
	PALESTRAS,
	WORKSHOPS,
	SEMINÁRIOS,
	MINICURSOS,
	COMPETIÇÕES;

}
