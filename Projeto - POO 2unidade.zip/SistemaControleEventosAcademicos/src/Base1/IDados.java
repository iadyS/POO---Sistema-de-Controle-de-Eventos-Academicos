package Base1;

import java.util.List;
import java.util.Set;

public interface IDados {
	
	public Set<Estudante> getEstudante();
	public List<Administrador> getAdministrador();
	public List<Evento> getEventos();
	public List<Evento> mostrarEvento();
	public boolean addEstudante(Estudante estud);
	public boolean addAdministrador(Administrador adm);
	public boolean removeEstudante(Estudante estud);
	public void executarMenu();
	
}
