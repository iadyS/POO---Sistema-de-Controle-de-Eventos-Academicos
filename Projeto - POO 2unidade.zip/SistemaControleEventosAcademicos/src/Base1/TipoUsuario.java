package Base1;

public enum TipoUsuario {

	ESTUDANTE ("Estudante"),
	ADMINISTRADOR ("Administrador");
	
	private String descricao;

	private TipoUsuario(String descrição) {
		this.descricao = descrição;
	}

	public String getDescrição() {
		return descricao;
	}
	
}
