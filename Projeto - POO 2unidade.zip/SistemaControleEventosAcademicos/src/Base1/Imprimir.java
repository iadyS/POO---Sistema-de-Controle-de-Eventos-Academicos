package Base1;

import java.util.List;
import java.util.Set;

public class Imprimir {

	
    public static void exibirEventos(List<Evento> mostrarEventos) {
    	 System.out.println();
    	 System.out.println("\n======================= EVENTOS =======================");
    	 System.out.println();

    	   
    	    for (Evento evento : mostrarEventos) {
    	        System.out.println("\n===============================");
    	        System.out.println();
    	        System.out.println("	EVENTO: " + evento.getNomeEvento().toUpperCase());
    	        System.out.println("	TIPO: " + evento.getEvento());
    	        System.out.println("	DATA: " + evento.getDataEvento());
    	        System.out.println("	HORA: " + evento.getHoraInicio() + " - " + evento.getHoraFim());
    	        System.out.println("	CAPACIDADE MÁXIMA: " + evento.getCapcMaxima());
    	        System.out.println();
    	        System.out.println("===============================");
    	    }
    	    System.out.println();
    	    System.out.println("=====================================================");
    	    System.out.println();
    }


    public static void exibirEstudantes(Set<Estudante> estudantes) {
        if (estudantes.isEmpty()) {
        	System.out.println();
            System.err.println("	NENHUM ESTUDANTE CADASTRADO	");
            System.out.println();
        } else {
        	System.out.println();
            System.out.println("	\nESTUDANTE CADASTRADO:	");
            System.out.println();
            for (Estudante estudante : estudantes) {
            	System.out.println();
                System.out.println("Nome: " + estudante.getNome());
                System.out.println("Matrícula: " + estudante.getId());
                System.out.println("Tipo: " + estudante.getTipoUsuario() + "\n");
                System.out.println();
            }
        }
    }


    public static void exibirAdministradores(List<Administrador> administradores) {
        if (administradores.isEmpty()) {
        	System.out.println();
            System.err.println("	NENHUM ADMINISTRADOR CADASTRADO	");
            System.out.println();
        } else {
        	System.out.println();
            System.out.println("	\nADMINISTRADOR CADASTRADO	");
            System.out.println();
            for (Administrador admin : administradores) {
                System.out.println("	Nome: " + admin.getNome());
                System.out.println("	ID: " + admin.getId());
                System.out.println("	Tipo: " + admin.getTipoUsuario() + "\n");
                System.out.println();
            }
        }
    }

	public static void exibirEstudanteEvento(List<Evento> eventos) {
		if (eventos.isEmpty()) {
			System.out.println();
            System.err.println("	NENHUM EVENTO DISPONIVEL ");
            System.out.println();
            return;
        }
		System.out.println();
        System.out.println("\n======================= EVENTOS =======================");
        System.out.println();
        for (Evento evento : eventos) {

            System.out.println("	\nEVENTO: " + evento.getNomeEvento().toUpperCase());
            System.out.println("	DATA: " + evento.getDataEvento());
            System.out.println("	HORA INÍCIO: " + evento.getHoraInicio() + " | HORA FIM: " + evento.getHoraFim());
            
            
            Set<Estudante> inscritos = evento.getEstudInscritos();
            if (inscritos.isEmpty()) {
            	System.out.println();
                System.err.println("	NENHUM ESTUDANTE INSCRITO NESTE EVENTO	");
                System.out.println();
            } else {
            	System.out.println();
                System.out.println("	ESTUDANTES INSCRITOS:");
                System.out.println();
                for (Estudante estudante : inscritos) {
                    System.out.println("	- Nome: " + estudante.getNome() + ", Matrícula: " + estudante.getId());
                }
            }
            System.out.println();
            System.out.println("---------------------------------------------------------");
        }
        System.out.println("==========================================================");
        System.out.println();
    }
		
}
