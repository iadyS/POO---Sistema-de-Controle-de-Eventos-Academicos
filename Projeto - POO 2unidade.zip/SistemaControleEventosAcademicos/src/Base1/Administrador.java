package Base1;

public class Administrador extends Usuario {

	public Administrador(String nome, Integer id) {
		super(nome, id, TipoUsuario.ADMINISTRADOR);
	}

	@Override
	public String getTipoUsuario() {
		return "Administrador";
	}

}
