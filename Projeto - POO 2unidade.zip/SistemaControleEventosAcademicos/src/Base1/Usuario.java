package Base1;

public abstract class Usuario {
	
	private String nome;
	private Integer id;
	private TipoUsuario usuario;


	public Usuario(String nome, Integer id, TipoUsuario usuario) {
	
		this.nome = nome;
		this.id = id;
		this.usuario = usuario;
	}

	public String getNome() {
		return nome;
	}

	public Integer getId() {
		return id;
	}

	public TipoUsuario getUsuario() {
		return usuario;
	}

	@Override
	public String toString() {
		return "Usuario [nome=" + nome + ", id=" + id + ", usuario=" + usuario + "]";
	}
	
	public abstract String getTipoUsuario();
	
}
