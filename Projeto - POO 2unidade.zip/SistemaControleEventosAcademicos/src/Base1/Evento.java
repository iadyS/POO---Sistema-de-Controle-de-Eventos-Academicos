package Base1;

import java.util.HashSet;
import java.util.Set;

public class Evento {
	
	private String nomeEvento;
	private TipoEvento evento;
	private Integer capcMaxima;
	private Set<Estudante> estudInscritos; 
	private Administrador admin;
	private String dataEvento;
	private String horaFim;
	private String horaInicio;
	

	public Evento(String nomeEvento, TipoEvento evento, Integer capcMaxima,
			Set<Estudante> estudantesInscritos, Administrador admin, String dataEvento, String horaFim, String horaInicio) {
		super();
		this.nomeEvento = nomeEvento;
		this.evento = evento;
		this.capcMaxima = capcMaxima;
		this.estudInscritos = new HashSet<>();
		this.admin = admin;
		this.dataEvento = dataEvento;
		this.horaFim = horaFim;
		this.horaInicio = horaInicio;
	}

	
	 public boolean addEstudante(Estudante estudante) throws CapacidadeMaximaException {
	        if (estudInscritos.size() >= capcMaxima) {
	            throw new CapacidadeMaximaException("Capacidade máxima do evento " + nomeEvento + " atingida!");
	        }
	        return estudInscritos.add(estudante);
	    }
	 
	 public void verificarCapacidadeMinima() throws CapacidadeMinimaException {
	        if (estudInscritos.size() < 2) {
	            throw new CapacidadeMinimaException("O evento " + nomeEvento + " precisa de no mínimo 2 estudantes.");
	        }
	    }
	
	
	public String getNomeEvento() {
		return nomeEvento;
	}



	public void setNomeEvento(String nomeEvento) {
		this.nomeEvento = nomeEvento;
	}



	public TipoEvento getEvento() {
		return evento;
	}



	public void setEvento(TipoEvento evento) {
		this.evento = evento;
	}



	public Integer getCapcMaxima() {
		return capcMaxima;
	}



	public void setCapcMaxima(Integer capcMaxima) {
		this.capcMaxima = capcMaxima;
	}



	public Set<Estudante> getEstudInscritos() {
		return estudInscritos;
	}



	public void setEstudInscritos(Set<Estudante> estudInscritos) {
		this.estudInscritos = estudInscritos;
	}



	public Administrador getAdmin() {
		return admin;
	}



	public void setAdmin(Administrador admin) {
		this.admin = admin;
	}



	public String getDataEvento() {
		return dataEvento;
	}



	public void setDataEvento(String dataEvento) {
		this.dataEvento = dataEvento;
	}



	public String getHoraFim() {
		return horaFim;
	}



	public void setHoraFim(String horaFim) {
		this.horaFim = horaFim;
	}



	public String getHoraInicio() {
		return horaInicio;
	}



	public void setHoraInicio(String horaInicio) {
		this.horaInicio = horaInicio;
	}



	@Override
	public String toString() {
		return "Evento [nomeEvento=" + nomeEvento + ", evento=" + evento + ", capcMaxima=" + capcMaxima
				+ ", estudInscritos=" + estudInscritos + ", admin=" + admin + ", dataEvento=" + dataEvento
				+ ", horaFim=" + horaFim + ", horaInicio=" + horaInicio + "]";
	}

}
