package Base1;

@SuppressWarnings("serial")
public class CapacidadeMaximaException extends Exception {
	
	  public CapacidadeMaximaException() {
	        super("Capacidade máxima do evento atingida!"); 
	    }
	  
	  public CapacidadeMaximaException(String mensagem) {
	        super(mensagem);
	    }

}
