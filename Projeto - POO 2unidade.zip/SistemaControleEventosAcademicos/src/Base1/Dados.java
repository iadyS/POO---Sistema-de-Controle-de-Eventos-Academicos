package Base1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.Set;


public class Dados implements IDados {
	
    private Set<Estudante> estudantes;
    private List<Administrador> administradores;
    private List<Evento> eventos;

    public Dados() {
        estudantes = new HashSet<>();
        administradores = new ArrayList<>();
        eventos = new ArrayList<>();
    }

    @Override
    public Set<Estudante> getEstudante() {
    	    return estudantes;
    	}

    @Override
    public List<Administrador> getAdministrador() {
        return administradores;
    }
    
    @Override
    public List<Evento> getEventos() {
  
        if (eventos.isEmpty()) {
            Set<Estudante> estudantesInscritos = new HashSet<>();
            
            if (!administradores.isEmpty()) {
                eventos.add(new Evento("Minicurso de Python", TipoEvento.MINICURSOS, 10, estudantesInscritos, administradores.get(0), "30/11/2024", "13:30", "17:30"));
                eventos.add(new Evento("Workshop de Java", TipoEvento.WORKSHOPS, 10, estudantesInscritos, administradores.get(0), "01/12/2024", "10:00", "14:00"));
                eventos.add(new Evento("Seminário de IA", TipoEvento.SEMINÁRIOS, 10, estudantesInscritos, administradores.get(0), "02/12/2024", "09:00", "12:00"));
            } else {
            	System.out.println();
            	System.err.println("	NENHUM ADMINISTRADOR CADASTRADO. NÃO É POSSÍVEL CRIAR EVENTOS." );
                System.out.println();
            }
        }

        return eventos; 
    }
    
    @Override
	public List<Evento> mostrarEvento() {
    	List<Evento> mostrarEventos = new ArrayList<>();
    	
    	 mostrarEventos.add(new Evento("Minicurso de Python", TipoEvento.MINICURSOS, 10, null, null, "30/11/2024", "13:30", "17:30"));
    	 mostrarEventos.add(new Evento("Workshop de Java", TipoEvento.WORKSHOPS, 10, null, null, "01/12/2024", "10:00", "14:00"));
    	 mostrarEventos.add(new Evento("Seminário de IA", TipoEvento.SEMINÁRIOS, 10, null, null, "02/12/2024", "09:00", "12:00"));
		
         return mostrarEventos;
	}

    
    @Override
    public boolean addEstudante(Estudante estud) {
    	
    	for (Estudante e : estudantes) {
    		
            if (e.getNome().equalsIgnoreCase(estud.getNome())) {
            	System.out.println();
                System.err.println("	ERRO: ESTUDANTE COM O NOME '" + estud.getNome() + " JÁ ESTÁ CADASTRADO.");
                System.out.println();
                return false;
            }
            
            if (e.getId() == estud.getId()) {
            	System.out.println();
                System.err.println("	ERRO: ESTUDANTE COM O NÚMERO DE MATRÍCULA " + estud.getId() + " JÁ ESTÁ CADASTRADO.");
                System.out.println();
                return false;
            }
        }
    	
    	estudantes.add(estud);
        return true;
    }
    
    @Override
    public boolean addAdministrador(Administrador adm) {
    	 if (administradores.isEmpty()) {
             administradores.add(adm);
             return true;
         } else {
             return false; 
         }
    }

    @Override
    public boolean removeEstudante(Estudante estud) {

    	if (estudantes.contains(estud)) {
            estudantes.remove(estud);
            return true;
        } else {
            return false;
        }
    }

	public void executarMenu() {
		
		Scanner sc = new Scanner(System.in);
        boolean continuar = true;

        while (continuar) {
        	System.out.println("\n==================== MENU ====================");
        	System.out.println();
        	System.out.println();
            System.out.println("	1. Adicionar Estudante");
            System.out.println("	2. Adicionar Administrador");
            System.out.println("	3. Cadastrar Estudante em Evento");
            System.out.println("	4. Exibir Todos os Eventos");
            System.out.println("	5. Exibir Todos os Estudantes");
            System.out.println("	6. Exibir Todos os Administradores");
            System.out.println("	7. Exibir Estudante por Evento");
            System.out.println("	8. Excluir Estudante");
            System.out.println("	9. Sair");
            System.out.println();
            System.out.println("===============================================");
            System.out.println();
            System.out.println();
            System.out.print("	Escolha uma opção: ");
            System.out.println();
            
            int opcao = sc.nextInt();
            sc.nextLine(); // Limpar o buffer

            switch (opcao) {
                case 1:
                    capturarDadosEstudante(sc);
                    break;
                case 2:
                    adicionarAdministrador(sc);
                    break;
                case 3:
                	exibirEventosECadastrar(sc);
                    break;
                case 4:
                    Imprimir.exibirEventos(mostrarEvento());
                    break;
                case 5:
                    Imprimir.exibirEstudantes(estudantes);
                    break;
                case 6:
                    Imprimir.exibirAdministradores(administradores);
                    break;
                case 7:
                	Imprimir.exibirEstudanteEvento(eventos);
                    break;
                case 8:
                    excluirEstudante(sc);
                    break;
                case 9:
                    continuar = false;
                    System.out.println("	...Saindo do sistema...");
                    break;
                default:
                    System.err.println("	OPÇÃO INVÁLIDA! TENTE NOVAMENTE.");
            }
        }
        
        sc.close();
    }

    private Estudante capturarDadosEstudante(Scanner sc) {
        System.out.print("	DIGITE O NOME DO ESTUDANTE: ");
        System.out.println();
        String nome = sc.nextLine();
        nome = retornaMaiuscula(nome);

        int id = -1;
        boolean idValido = false;
        while (!idValido) {
        	System.out.print("	DIGITE O NÚMERO DE MATRÍCULA DO ESTUDANTE: ");
        	System.out.println();
            try {
                id = sc.nextInt();
                idValido = true;
            } catch (InputMismatchException e) {
            	 System.err.println("	ENTRADA INVÁLIDA! POR FAVOR, INSIRA APENAS NÚMEROS.");
            	 System.out.println();
                 sc.nextLine(); 
            }
        }

        sc.nextLine(); 
        Estudante estudante = new Estudante(nome, id);

        if (addEstudante(estudante)) {
            return estudante;
        } else {
        	System.out.println();
        	System.err.println("	ERRO:' ESTUDANTE COM NOME '" + estudante.getNome() + "' OU NÚMERO DE MATRÍCULA '"
					+ estudante.getId() + "' JÁ ESTÁ CADASTRADO.'");
        	System.out.println();
        	return null;
        }

    }
	
	private void adicionarAdministrador(Scanner sc) {
	    if (administradores.isEmpty()) { 
	    	System.out.println();
	        System.out.print("	DIGITE O NOME DO ADMINISTRADOR: ");
	        String nome = sc.nextLine();
	        nome = retornaMaiuscula(nome);

	        Administrador administrador = new Administrador(nome, 1); 
	        addAdministrador(administrador);
	        System.out.println("	ADMINISTRADOR " + nome.toUpperCase() + " ADICIONADO COM SUCESSO!");
	        System.out.println();
	    } else {
	    	System.out.println();
	        System.err.println("	JÁ EXISTE UM ADMINISTRADOR CADASTRADO!");
	        System.out.println();
	    }
	}
	
	
	private void exibirEventosECadastrar(Scanner sc) {
		
	    List<Evento> eventos = getEventos();
	    
	    System.out.println();
	    System.out.println("	EVENTOS DISPONÍVEIS PARA INSCRIÇÃO:");
	    System.out.println();
	    for (int i = 0; i < eventos.size(); i++) {
	        Evento evento = eventos.get(i);
	        System.out.println();
	        System.out.println((i + 1) + "		. " + evento.getNomeEvento() + " - Data: " + evento.getDataEvento());
	    }
	    System.out.println();
	    System.out.print("		ESCOLHA O EVENTO PARA INSCRIÇÃO (1 - " + eventos.size() + "): ");
	    int escolhaEvento = sc.nextInt();
	    sc.nextLine();  

	    if (escolhaEvento < 1 || escolhaEvento > eventos.size()) {
	    	System.err.println("	OPÇÃO INVÁLIDA! TENTE NOVAMENTE.");
	    	System.out.println();
	        return;
	    }

	    Evento eventoEscolhido = eventos.get(escolhaEvento - 1);
	    
	    Estudante estudante = capturarDadosEstudante(sc);
	    try {
	        eventoEscolhido.addEstudante(estudante);
	        System.out.println("	ESTUDANTE " + estudante.getNome() + " INSCRITO NO EVENTO  " + eventoEscolhido.getNomeEvento());

	        eventoEscolhido.verificarCapacidadeMinima();
	        
	    } catch (CapacidadeMaximaException e) {
	        System.err.println(e.getMessage());
	    } catch (CapacidadeMinimaException e) {
	        System.err.println(e.getMessage());
	    }
	}
	
	private void excluirEstudante(Scanner sc) {
		System.out.println();
	    System.out.print("	DIGITE O NOME DO ESTUDANTE PARA EXCLUSÃO: ");
	    String nome = sc.nextLine();
	    
	    Estudante estudante = estudantes.stream()
	        .filter(e -> e.getNome().equals(nome))
	        .findFirst()
	        .orElse(null);
	    
	    if (estudante != null) {
	        removeEstudante(estudante);
	        System.out.println("    ESTUDANTE REMOVIDO COM SUCESSO!");
	    } else {
	    	System.err.println("	ESTUDANTE NÃO ENCONTRADO.");
	    	System.out.println();
	    }
	}
	
	
    private static String retornaMaiuscula(String palavra) {
        return palavra.substring(0, 1).toUpperCase() + palavra.substring(1).toLowerCase();
    }

}

