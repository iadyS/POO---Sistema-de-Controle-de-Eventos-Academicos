package Base1;

public class Estudante extends Usuario {

	public Estudante(String nome, Integer id) {
		super(nome, id, TipoUsuario.ESTUDANTE);
		
	}

	@Override
	public String getTipoUsuario() {

		return "Estudante";
	}
	
}
