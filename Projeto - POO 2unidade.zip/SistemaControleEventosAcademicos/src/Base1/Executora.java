package Base1;

public class Executora {

	public static void main(String[] args) {
	
		 Dados dados = new Dados();
		   
	        dados.executarMenu();
	   }

}

